package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DataReader {
    public List<String> readData(String filePath) {
        List<String> data = new ArrayList<>();
        try {
            // Створення об'єкту URL на основі filePath
            URL url = new URL(filePath);

            // Використання методу openStream() для отримання вхідного потоку даних з URL
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                data.add(line);
            }
            reader.close();
        } catch (IOException e) {
            // Обробка винятку, якщо щось пішло не так під час читання даних
            e.printStackTrace();
        }
        return data;
    }
}
