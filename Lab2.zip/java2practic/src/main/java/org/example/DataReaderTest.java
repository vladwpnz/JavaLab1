package org.example;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.List;

public class DataReaderTest {

    @Test
    public void testReadData() {
        // Підготовка тестових даних
        String filePath = "https://informer.com.ua/dut/java/pr2.csv";
        List<String> expectedLines = List.of("line1", "line2", "line3");

        // Створення об'єкту DataReader
        DataReader dataReader = new DataReader();

        // Виклик методу, який потрібно протестувати
        List<String> actualLines = dataReader.readData(filePath);

        // Перевірка результату
        Assertions.assertEquals(expectedLines.size(), actualLines.size(), "Кількість рядків не співпадає");

        for (int i = 0; i < expectedLines.size(); i++) {
            Assertions.assertEquals(expectedLines.get(i), actualLines.get(i), "Рядок " + (i + 1) + " не співпадає");
        }
    }
}
